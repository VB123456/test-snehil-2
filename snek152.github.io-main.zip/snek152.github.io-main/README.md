# Snehil Kakani's Official Website

Built in React and Sass.
snehilkakani.me
