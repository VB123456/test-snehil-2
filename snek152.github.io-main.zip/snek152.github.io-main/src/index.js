import React from "react"
import ReactDOM from "react-dom"
import $ from "jquery"
import Isotope from "isotope-layout"
import "bootstrap"
import "@popperjs/core"
import AOS from "aos"
import "aos/dist/aos.css"
import { Popover, Collapse } from "bootstrap"
import jQueryBridget from "jquery-bridget"

// Components
import "./index.scss"

import About from "./components/About"
import Home from "./components/Home"
import Socials from "./components/Socials"
import Navbar from "./components/Navbar"
import Preloader, { ProjectModal } from "./components/App"
import Skills from "./components/Skills"
import Portfolio from "./components/Portfolio"
import Footer from "./components/Footer"
import Contact from "./components/Contact"

jQueryBridget("isotope", Isotope, $)

ReactDOM.render(
    <React.StrictMode>
        <Socials />
    </React.StrictMode>,
    document.getElementById("social-media")
)
ReactDOM.render(
    <React.StrictMode>
        <Preloader />
        <Navbar />
        <Home />
        <About />
        <Skills />
        <Portfolio />
        <Contact />
        <Footer />
    </React.StrictMode>,
    document.getElementById("container")
)

ReactDOM.render(
    <React.StrictMode>
        <ProjectModal />
    </React.StrictMode>,
    document.getElementById("modals")
)

AOS.init({
    once: true
}) // Initializing Animate On Scroll

// Preloader
$(window).ready(function () {
    setTimeout(function () { $("#preloading").fadeOut(); document.querySelector("body").style.overflow = "auto" }, 3000)
})


// Removing url ids
$(window).on('hashchange', function (e) {
    window.history.replaceState("", document.title, e.originalEvent.oldURL)
})



// Various things that execute over time
$(function () {
    if ($(window).height() > $(".project-grid").height()) {
        $(".project-grid").css("min-height", $(".project-grid").height())
    } else {
        $(".project-grid").css("transition", "height 0.5s ease-in-out")
    }
    let x = new RandomObjectMover(document.getElementById("floating-icon1"), document.getElementById("mainpage"))
    let y = new RandomObjectMover(document.getElementById("floating-icon2"), document.getElementById("mainpage"))
    let z = new RandomObjectMover(document.getElementById("floating-icon3"), document.getElementById("mainpage"))
    let a = new RandomObjectMover(document.getElementById("floating-icon4"), document.getElementById("mainpage"))
    let b = new RandomObjectMover(document.getElementById("floating-icon5"), document.getElementById("mainpage"))
    let c = new RandomObjectMover(document.getElementById("floating-icon6"), document.getElementById("mainpage"))


    x.start()
    y.start()
    z.start()
    a.start()
    b.start()
    c.start()

    const parentwidth = $('.container').width()
    const child = document.getElementById('navbarhead')
    child.style.width = `${parentwidth}px`

    $(window).resize(function () {
        const parentwidth = $('.container').width()
        const child = document.getElementById('navbarhead')
        child.style.width = `${parentwidth}px`
    })

    $('#musicLink').on('click', function () {
        $("#musicFilter").trigger("click")
    })

    $('#designLink').on('click', function () {
        $("#designFilter").trigger("click")
    })

    $('#codeLink').on('click', function () {
        $("#codeFilter").trigger("click")
    })

    $('#projectLink').on('click', function () {
        $("#projectFilter").trigger("click")
    })

    if (!('scroll-behavior' in document.body.style)) {
        $(".home").click(function () {
            $([document.documentElement, document.body]).animate({
                scrollTop: $("#mainpage").offset().top
            }, 800, "swing")
        })

        $(".about").click(function () {
            $([document.documentElement, document.body]).animate({
                scrollTop: $("#about").offset().top
            }, 800, "swing")
        })

        $(".skills").click(function () {
            $([document.documentElement, document.body]).animate({
                scrollTop: $("#expertise").offset().top
            }, 800, "swing")
        })

        $(".projects").click(function () {
            $([document.documentElement, document.body]).animate({
                scrollTop: $("#projects").offset().top
            }, 800, "swing")
        })

        $(".topbutton-button").click(function () {
            $([document.documentElement, document.body]).animate({
                scrollTop: $("#mainpage").offset().top
            }, 800, "swing")
        })

        $('#down-button a button').click(function () {
            $([document.documentElement, document.body]).animate({
                scrollTop: $("#about").offset().top
            }, 800, "swing")
        })
    }

    if (navigator.userAgent.includes("Firefox")) {
        let backgroundradius = "3rem"
        $('.spinner *').css('background-image', 'url("images/bounce.svg")')
        $('.spinner *').css('border-radius', backgroundradius)
        $('.spinner *').css('width', '1.5em')
        $('.spinner *').css('height', '1.5em')
    }
    if (navigator.userAgent.includes("iPhone")) {
        $('.social-button>i').css({ 'transform': 'translate(-0.5rem, 0)', 'display': 'block' })
        $('.social-toggler i').css({ '-webkit-transform': 'rotate(180deg) translate(-.9rem)', 'transform': 'rotate(180deg) translate(-.9rem)', 'color': 'black' })
        $('.social-toggler.collapsed i').css({ '-webkit-transform': 'rotate(0deg) translate(-0.9rem)', 'transform': 'rotate(0deg) translate(-0.9rem)', 'color': 'black' })
        $('.topbutton-container i').css('-webkit-transform', 'translate(-.4rem, -.4rem')

    }

    var popoverTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="popover"]'))
    var popoverList = popoverTriggerList.map(function (popoverTriggerEl) {
        return new Popover(popoverTriggerEl)
    })
    $('.nav-link').on("click", () => {
        console.log($('.navbar-toggler').css("display"))
        if ($('.navbar-toggler').css("display") != "none") {
            var myCollapse = document.getElementById('navbarSupportedContent')
            var bsCollapse = new Collapse(myCollapse, {
                toggle: true
            })
        }
    })
})

// Initializing Isotope
$(window).on('load', function () {
    let portfolioIsotope = $('.project-grid').isotope({
        itemSelector: '.grid-item',
        layoutMode: 'fitRows',
        sortAscending: true
    })

    $('.filter-button-group button').on('click', function () {
        $(".filter-button-group button").removeClass('filter-active')
        $(this).addClass('filter-active')
        portfolioIsotope.isotope({
            filter: $(this).data('filter')
        })
    })
})


// Scroll for active class
let mainNavLinks = document.querySelectorAll("nav ul li a")

window.addEventListener("scroll", event => {
    let fromTop = window.scrollY

    mainNavLinks.forEach(link => {
        if (link.hash != "" && link.hash != "#" && !link.classList.contains("dropdown-item")) {
            let section = document.querySelector(link.hash)

            if (section.offsetTop - 1 <= fromTop && section.offsetTop + section.offsetHeight >= fromTop) {
                document.querySelectorAll('a').forEach(b => { if (!b.classList.contains("dropdown-item")) b.classList.remove("active") })
                link.classList.add("active")
                link.setAttribute("aria-current", "page")
            }

            else {
                link.classList.remove("active")
                link.removeAttribute("aria-current", "page")
            }
        }
    })
})

// Adding movement to icons in home

function RandomObjectMover(obj, container) {
    this.$object = obj
    this.$container = container
    this.container_is_window = container === window
    this.pixels_per_second = 75
    this.current_position = { x: Math.floor(Math.random() * 1000), y: Math.floor(Math.random() * 1000) }
    this.is_running = false
}

RandomObjectMover.prototype.setSpeed = function (pxPerSec) {
    this.pixels_per_second = pxPerSec
}

RandomObjectMover.prototype._getContainerDimensions = function () {
    if (this.$container === window) {
        return { 'height': this.$container.innerHeight, 'width': this.$container.innerWidth }
    } else {
        return { 'height': this.$container.clientHeight, 'width': this.$container.clientWidth }
    }
}

RandomObjectMover.prototype._generateNewPosition = function () {

    let containerSize = this._getContainerDimensions()
    let availableHeight = containerSize.height - this.$object.clientHeight
    let availableWidth = containerSize.width - this.$object.clientHeight

    let y = Math.floor(Math.random() * availableHeight)
    let x = Math.floor(Math.random() * availableWidth)

    return { x: x, y: y }
}

RandomObjectMover.prototype._calcDelta = function (a, b) {
    let dx = a.x - b.x
    let dy = a.y - b.y
    let dist = Math.sqrt(dx * dx + dy * dy)
    return dist
}

RandomObjectMover.prototype._moveOnce = function () {
    let next = this._generateNewPosition()

    let delta = this._calcDelta(this.current_position, next)

    let speed = Math.round((delta / this.pixels_per_second) * 100) / 100


    this.$object.style.transition = `transform ${speed}s linear`
    this.$object.style.transform = `translate3d(${next.x}px, ${next.y}px, 0)`

    this.current_position = next

}

RandomObjectMover.prototype.start = function () {

    if (this.is_running) {
        return
    }

    this.$object.willChange = 'transform'
    this.$object.pointerEvents = 'auto'

    this.boundEvent = this._moveOnce.bind(this)

    this.$object.addEventListener('transitionend', this.boundEvent)

    this._moveOnce()

    this.is_running = true
}

RandomObjectMover.prototype.stop = function () {

    if (!this.is_running) {
        return
    }

    this.$object.removeEventListener('transitionend', this.boundEvent)

    this.is_running = false
}


$('.social-toggler').click(function () {
    var selector = $(this).data("bs-target")
    $(selector).toggleClass("open")
    $(this).toggleClass("collapsed")
})

window.onscroll = function () { scrollFunction() }

function scrollFunction() {
    let mainpage = document.getElementById("mainpage")
    let topbutton = document.getElementById("topbutton")
    if (document.body.scrollTop >= mainpage.offsetHeight || document.documentElement.scrollTop >= mainpage.offsetHeight) {
        topbutton.style.transform = "scale(1.0)"
    } else {
        topbutton.style.transform = "scale(0)"
    }
}