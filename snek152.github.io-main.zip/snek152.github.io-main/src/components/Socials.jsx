import React from "react"
import { SocialIcons } from "./App"


function Socials() {
    return (
        <div className="social-container d-flex align-items-center">
            <div id="socialCollapse">
                <SocialIcons name="facebook" link="https://www.facebook.com/snehilkakani" />
                <SocialIcons name="instagram" link="https://instagram.com/sne.k152" />
                <SocialIcons name="linkedin" link="https://linkedin.com/in/snehilkakani" />
                <SocialIcons name="github" link="https://github.com/snek152" />
                <SocialIcons name="email" link="mailto:kakanisnehil@gmail.com?body=%0A%0A%0A%0A%0A%0A%0ASent from snehilkakani.me: the official website of Snehil Kakani." />
            </div>
            <button className="social-toggler collapsed" type="button" data-bs-target="#socialCollapse"
                aria-controls="socialCollapse" aria-expanded="true" aria-label="Toggle social icons">
                <i className="mdi mdi-chevron-right"></i>
            </button>
        </div>
    )
}

export default Socials