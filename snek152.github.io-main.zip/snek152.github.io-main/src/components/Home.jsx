import "../styles/Home.scss"

import code from "../images/code-slash.svg"
import design from "../images/vector-pen.svg"
import music from "../images/music-note-beamed.svg"
import gaming from "../images/controller.svg"
import debate from "../images/megaphone.svg"
import acting from "../images/person-lines-fill.svg"
import React from "react"
import { FloatingIcon } from "./App"


function Home() {
    return (
        <header id="mainpage" className="starter" data-aos="fade-up">

            <FloatingIcon image={code} num="1" />
            <FloatingIcon image={design} num="2" />
            <FloatingIcon image={music} num="3" />
            <FloatingIcon image={gaming} num="4" />
            <FloatingIcon image={debate} num="5" />
            <FloatingIcon image={acting} num="6" />
            <div id="down-button">
                <a href="#about">
                    <button style={{ border: "none", backgroundColor: "transparent" }}>
                        <i className="mdi mdi-chevron-double-down"></i>
                    </button>
                </a>
            </div>
        </header>
    )
}

export default Home