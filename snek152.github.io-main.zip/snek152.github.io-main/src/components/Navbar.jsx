import React from "react"

function Navbar() {
    return (
        <nav id="navbarhead" className="navbar navbar-expand-md navbar-dark bg-dark">
            <div className="container-fluid">
                <a className="navbar-brand" href="#">Snehil Kakani</a>
                <button className="navbar-toggler collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent"
                    aria-controls="navbarSupportedContent" aria-expanded="true" aria-label="Toggle navigation">
                    <span className="navbar-toggler-icon top-bar"></span>
                    <span className="navbar-toggler-icon middle-bar"></span>
                    <span className="navbar-toggler-icon bottom-bar"></span>
                </button>

                <div className="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul className="navbar-nav ms-auto mb-lg-0" style={{ marginBottom: "0 !important" }}>
                        <li className="nav-item">
                            <a className="nav-link active home" aria-current="page" href="#mainpage">Home</a>
                        </li>
                        <li className="nav-item">
                            <a className="nav-link about" href="#about">About</a>
                        </li>
                        <li className="nav-item">
                            <a className="nav-link skills" href="#expertise">Expertise</a>
                        </li>
                        <li className="nav-item dropdown button-group">
                            <a className="nav-link projects" href="#projects" id="projectLink">Projects</a>
                            <a className="nav-link dropdown-toggle dropdown-toggle-split" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false" style={{ paddingLeft: 0, verticalAlign: "middle" }}>
                                <span className="visually-hidden">Toggle Dropdown</span>
                            </a>
                            <ul className="dropdown-menu dropdown-menu-end dropdown-menu-dark" aria-labelledby="navbarDropdown">
                                <li><a className="dropdown-item" href="#projects" id="codeLink">Code Projects</a></li>
                                <li><a className="dropdown-item" href="#projects" id="designLink">Designs</a></li>
                                <li><a className="dropdown-item" href="#projects" id="musicLink">Music/Drama</a></li>
                            </ul>
                        </li>
                        <li className="nav-item">
                            <a className="nav-link contact" href="#contact">Contact</a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav >
    )
}

export default Navbar