import React from "react"
import $ from "jquery"

function Contact() {
    return (
        <section id="contact">
            <div className="spacer"></div>
            <h1>Contact Me</h1>
            <form onSubmit={contactSubmit} id="contactForm" className="mt-5">
                <div className="row">
                    <div className="col-lg-6 col-md-6">
                        <div className="mb-3 form-floating">
                            <input name="name" className="form-control" placeholder="Name" required />
                            <label>Name</label>
                        </div>
                    </div>
                    <div className="col-lg-6 col-md-6">
                        <div className="mb-3 form-floating">
                            <input name="email" type="email" className="form-control" placeholder="Email" required />
                            <label>Email</label>
                        </div>
                    </div>
                </div>
                <div className="mb-3 form-floating">
                    <textarea name="message" className="form-control" placeholder="Message" style={{ height: "10rem" }} required />
                    <label>Message</label>
                </div>
                <div className="mb-3">
                    <button type="submit" id="submit" className="btn btn-primary">Submit</button>
                </div>
            </form>
            <svg xmlns="http://www.w3.org/2000/svg" style={{ display: "none" }}>
                <symbol id="check-circle-fill" fill="currentColor" viewBox="0 0 16 16">
                    <path d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0zm-3.97-3.03a.75.75 0 0 0-1.08.022L7.477 9.417 5.384 7.323a.75.75 0 0 0-1.06 1.06L6.97 11.03a.75.75 0 0 0 1.079-.02l3.992-4.99a.75.75 0 0 0-.01-1.05z" />
                </symbol>
            </svg>
        </section>
    )
}
function contactSubmit(event) {
    event.preventDefault()
    $('[type=submit]').attr("disabled", "true")
    $('[type=submit]').html('<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>')
    $.ajax({
        type: "POST",
        contentType: "application/json",
        dataType: "json",
        url: "https://formspree.io/f/xyylnqbg",
        data: JSON.stringify({ "email": event.target.email.value, "message": event.target.message.value, "name": event.target.name.value }),
        success: function (data) {
            document.getElementById("contactForm").reset()
            $('[type=submit]').html('<svg style="width:18;height:18" viewBox="0 0 24 24"><path fill="currentColor" d="M9,20.42L2.79,14.21L5.62,11.38L9,14.77L18.88,4.88L21.71,7.71L9,20.42Z" /></svg>')
            setTimeout(() => {$("[type=submit]").removeAttr("disabled"); $("[type=submit]").html("Submit")}, 2000)
        }
    })
}

export default Contact