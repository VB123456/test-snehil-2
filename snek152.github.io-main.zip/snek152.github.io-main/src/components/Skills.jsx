import React from "react"

import "../styles/Skills.scss"
import { IconSkill } from "./App"
import code from "../images/code-square.svg"
import design from "../images/easel.svg"
import music from "../images/file-earmark-music.svg"

function Skills() {
    return (
        <section id="expertise" className="starter">
            <div className="spacer"></div>
            <div className="container" style={{ background: "inherit", paddingRight: "1rem !important", paddingLeft: "1rem !important" }}>
                <div className="grid row" data-aos="fade-up">
                    <div className="grid-item card col-lg me-2 padded-col mt-sm-3 ">
                        <img alt="Coding Icon" src={code} align="left" style={{ opacity: 0.65 }} />
                        <span>
                            <h3>Computer Science</h3>
                            <p>Being an avid programmer, I specialize in front-end and back-end web development, functional programming, and data structures. Here are some of the languages and platforms I'm proficient with.</p>
                        </span>
                        <div className="icon-grid" style={{ display: "inline-block" }}>
                            <IconSkill title="Python" width="95" icon="language-python" />
                            <IconSkill title="Java" width="95" icon="language-java" />
                            <IconSkill title="HTML" width="95" icon="language-html5" />
                            <IconSkill title="Git" width="95" icon="git" />
                            <IconSkill title="CSS" width="90" icon="language-css3" />
                            <IconSkill title="Bootstrap" width="85" icon="bootstrap" />
                            <IconSkill title="jQuery" width="80" icon="jquery" />
                            <IconSkill title="MongoDB" width="75" icon="leaf" />
                            <IconSkill title="Sass" width="70" icon="sass" />
                            <IconSkill title="Flask" width="70" icon="flask" />
                            <IconSkill title="Javascript" width="60" icon="language-javascript" />
                            <IconSkill title="ReactJS" width="55" icon="react" />
                            <IconSkill title="VueJS" width="50" icon="vuejs" />
                            <IconSkill title="SQL" width="50" icon="database-search" />
                            <IconSkill title="NodeJS" width="30" icon="nodejs" />
                            <div className="vr"></div>
                            <IconSkill title="Tailwind" icon="tailwind" learning="true" />
                            <IconSkill title="Unity" icon="unity" learning="true" />
                            <IconSkill title="Typescript" icon="language-typescript" learning="true" />
                        </div>
                    </div>
                    <div className="grid-item card col-lg me-2 padded-col mt-sm-3 ">
                        <img alt="Design Icon" src={design} align="left" style={{ opacity: 0.65 }} />
                        <span>
                            <h3>Graphic Design</h3>
                            <p>As a creative designer and budding artist, I enjoy designing Instagram posts, flyers, and ads for
                                various
                                companies and events. I use my love of art heavily in this field. Below are the platforms I work with.
                            </p>
                        </span>
                        <div className="icon-grid" style={{ display: "inline-block" }}>
                            <IconSkill title="Canva" width="90" icon="copyright" />
                            <IconSkill title="TinkerCAD" width="85" icon="cube-outline" />
                            <IconSkill title="Procreate" width="80" icon="draw" />
                            <IconSkill title="Figma" width="60" icon="drawing-box" />
                            <div className="vr"></div>
                            <IconSkill title="Blender" icon="blender-software" learning="true" />
                            <IconSkill title="Creative Cloud" icon="adobe" learning="true" />
                        </div>
                    </div>
                    <div className="grid-item card col-lg me-2 padded-col mt-sm-3 ">
                        <img alt="Music Icon" src={music} align="left" style={{ opacity: 0.65 }} />
                        <span>
                            <h3>Music</h3>
                            <p>One of my greatest and longest lasting passions is music. Over the years, I have learned quite a few
                                instruments and software platforms to use in my music creation. Outlined are these platforms and instruments.</p>
                        </span>
                        <div className="icon-grid" style={{ display: "inline-block" }}>
                            <IconSkill title="Drums" width="80" icon="checkbox-multiple-blank-circle-outline mdi-rotate-90" />
                            <IconSkill title="GarageBand" width="75" icon="guitar-acoustic" />
                            <IconSkill title="Piano" width="60" icon="piano" />
                            <IconSkill title="SoundCloud" width="55" icon="soundcloud" />
                            <IconSkill title="Clarinet" width="50" icon="trumpet" />
                        </div>
                    </div>
                </div>
            </div>
        </section>
    )
}

export default Skills