import React, { useEffect, useRef } from "react"
import Typed from "typed.js"
import $ from "jquery"

import "../styles/About.scss"
import image from "../images/aboutphoto.jpg"
import envelope from "../images/envelope-fill.svg"
import building from "../images/building.svg"


function AboutInfo() {
    return (
        <div id="infocard" style={{ overflowWrap: "anywhere" }} className="row">
            <div className="flex-item-card col-sm-12 col-md-12 col-lg-12">
                <img alt="Email Icon" src={envelope} />
                <p>kakanisnehil@gmail.com</p>
                <br />
                <img alt="School Icon" src={building} />
                <p>Freshman at Lynbrook High School</p>
            </div>
        </div>
    )
}

function About() {
    const el = useRef(null)
    const typed = useRef(null)
    useEffect(() => {
        $(function () {
            typed.current = new Typed(el.current, {
                strings: ["I'm a frontend engineer", "I'm a backend developer", "I'm an innovator", "I'm a graphic designer", "I'm a drummer"],
                typeSpeed: 80,
                smartBackspace: true,
                backDelay: 600,
                backSpeed: 40,
                loop: true,
                loopCount: Infinity,
            })
        })
        return () => {
            typed.current.destroy()
        }
    }, [])

    return (
        <section id="about" className="starter">
            <div className="spacer"></div>
            <div className="card mb-3" style={{ maxWidth: "1500px", borderRadius: "1.25rem", margin: "auto" }} data-aos="fade-up">
                <div className="row g-0">
                    <div className="col-md-12 col-lg-5" style={{ overflow: "hidden" }}>
                        <img src={image} id="aboutphoto" alt="An image of myself." className="img-fluid" />
                    </div>
                    <div className="col-md-12 col-lg-7 padded-col">
                        <div className="card-body" data-aos="fade-up">
                            <h3 className="card-title"><span className="typed-element" ref={el}></span></h3>
                            <h5 className="card-text">Hi! My name is Snehil, and I'm an aspiring programmer. I love working on solid, flexible UIs in the frontend, and creating APIs and server apps in the backend. I'm also a professional graphic designer, drummer, actor, and more! You can find me on <a style={{cursor: 'pointer', color: "#1266f1"}} onClick={() => {$('.social-toggler').click()}}>social media</a>, or <a href="#contact">contact me directly</a>.</h5>
                            <AboutInfo />
                            <hr />
                            <div id="jobshobbies" style={{ overflowWrap: "anywhere" }} className="row">
                                <div className="flex-item-card col-sm-12 col-md-12 col-lg-6">
                                    <h4>Professional Experience</h4>
                                    <div className="accordion accordion-flush" id="professional">
                                        <div className="accordion-item">
                                            <h2 className="accordion-header" id="headingOne">
                                                <button className="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="false" aria-controls="collapseOne">Graphic Designer @ Youth Economics Initiative</button>
                                            </h2>
                                            <div id="collapseOne" className="accordion-collapse collapse" aria-labelledby="headingOne" data-bs-parent="#professional">
                                                <div className="accordion-body">
                                                    <p> As a graphic designer at the <a href="https://theyei.org" target="_blank" rel="noopener">YEI</a>, I make professional Instagram posts and stories to promote their events, as well as educating people about economics. To accomplish this, I use the graphic design platform <a href="https://canva.com" target="_blank" rel="noopener">Canva</a>. </p>
                                                </div>
                                            </div>
                                        </div>
                                        <div className="accordion-item">
                                            <h2 className="accordion-header" id="headingTwo">
                                                <button className="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">Full Stack Web Developer @ YoungWonks Open Source Project 2021</button>
                                            </h2>
                                            <div id="collapseTwo" className="accordion-collapse collapse" aria-labelledby="headingTwo" data-bs-parent="#professional">
                                                <div className="accordion-body">
                                                    <p>In the summer of 2021, I was selected into an open source project called GeoRepair <a href="#projects">(learn more)</a>. I worked as a frontend developer and created the homepage, forum page, and assisted in creating basic backend functionalities.</p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <section className="flex-item-card col-sm-12 col-md-12 col-lg-6">
                                    <h4>Interests</h4>
                                    <ul style={{ overflowWrap: "break-word" }}>
                                        <li>Full stack web development (frontend and backend)</li>
                                        <li>Designing flyers and posts</li>
                                        <li>Drumming</li>
                                        <li>Video games</li>
                                        <li>Algorithms in Java and Python</li>
                                        <li>Minecraft modding</li>
                                    </ul>
                                </section>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    )
}

export default About