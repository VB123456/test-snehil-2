import React, { Fragment } from "react"
import { Project } from "./App"
import "../styles/Portfolio.scss"


import beatbox from "../images/beatbox.png"
import album from "../images/drums2021.png"
import romeojuliet from "../images/romeojuliet2122.jpg"
import georepair from "../images/georepair.png"
import dook from "../images/dook.png"
import swordselection from "../images/swordselection.png"
import albumcovers from "../images/albumcovers.png"
import econconcepts from "../images/econconcepts.png"
import checkplease from "../images/checkplease.png"

function Portfolio() {
    return (
        <section id="projects" className="starter" data-aos-anchor-position="top-bottom">
            <div className="spacer"></div>
            <h1 data-aos="fade-up" data-aos-anchor="#projects" data-aos-anchor-position="top-bottom">Projects</h1>
            <div className="d-flex justify-content-center">
                <div className="button-group filter-button-group" role="group"
                    aria-label="Filter button group" data-aos="fade-up" data-aos-anchor="#projects"
                    data-aos-anchor-position="top-bottom">
                    <button data-filter="*" type="button" className="btn filter-button filter-active" id="projectFilter">All</button>
                    <button data-filter=".cs" type="button" className="btn filter-button" id="codeFilter">Code Projects</button>
                    <button data-filter=".design" type="button" className="btn filter-button" id="designFilter">Designs</button>
                    <button data-filter=".music" type="button" className="btn filter-button" id="musicFilter">Music/Drama</button>
                </div>
            </div>
            <div className="project-grid" data-isotope='{ "itemSelector": ".grid-item", "layoutMode": "fitRows"}'>
                <Project header="Beat Box - Music Album" type="music" image={beatbox}
                    desc="One of my first albums produced with GarageBand, this was my first step towards developing DJ skills."
                    button={<a href="https://soundcloud.com/snek152/sets/beat-box" target="_blank" rel="noopener">
                        <button className="btn btn-light">
                            <i className="mdi mdi-open-in-new"></i><span style={{ width: 2, display: "inline-block" }}></span>
                            listen on soundcloud
                        </button>
                    </a>} />
                <Project header="Check Please Valentine's Day Show 2022 - LHS Studio 74" type="music" image={checkplease}
                    desc="In Lynbrook High School Studio 74's annual Valentine's Day show, I have been cast as
                    the young Tod in the play Check Please, performing in February 2022."
                    button={<a href="https://www.playscripts.com/play/202" target="_blank" rel="noopener">
                        <button className="btn btn-light">
                            <i className="mdi mdi-open-in-new"></i><span style={{ width: 2, display: "inline-block" }}></span>view on playscript
                        </button>
                    </a>} />
                <Project header="Drum Performance Song 2021" type="music" image={album}
                    desc={`As part of my annual drum showcase, I performed "Whistle" by Flo Rida on my drumset.`}
                    button={<a href="https://youtube.com/channel/UCZtK7CLB6ZSxS1-6Sge435A/videos" target="_blank" rel="noopener">
                        <button className="btn btn-light">
                            <i className="mdi mdi-open-in-new"></i><span style={{ width: 2, display: "inline-block" }}></span>
                            watch on youtube
                        </button>
                    </a>} />
                <Project header="Dook - An Opportunity App" type="cs" image={dook} subheader={<span><a className="chip" style={{ display: "inline-block" }} href="https://html.spec.whatwg.org/multipage/" rel="noopener" target="_blank">HTML</a> <a className="chip" style={{ display: "inline-block" }} href="https://www.w3.org/Style/CSS" rel="noopener" target="_blank">CSS</a> <a className="chip" style={{ display: "inline-block" }} href="https://getbootstrap.com" rel="noopener" target="_blank">Bootstrap</a></span>}
                    desc="As part of Elevate the Future's Project Falcon, myself and other web developers created a website for Dook to promote their platform."
                    button={<Fragment>
                        <a href="https://dookapp.com" target="_blank" rel="noopener">
                            <button className="btn btn-light">
                                <i className="mdi mdi-open-in-new"></i><span style={{ width: 2, display: "inline-block" }}></span>
                                check it out
                            </button>
                        </a>
                        <span> </span>
                        <a href="https://elevatethefuture.org/projectfalcon" target="_blank" rel="noopener">
                            <button className="btn btn-light">
                                <i className="mdi mdi-open-in-new"></i><span style={{ width: 2, display: "inline-block" }}></span>
                                learn more
                            </button>
                        </a>
                    </Fragment>} />
                <Project header="GeoRepair - An Open-Source Project" type="cs" image={georepair} subheader={<span><a className="chip" style={{ display: "inline-block" }} href="https://html.spec.whatwg.org/multipage" rel="noopener" target="_blank">HTML</a> <a className="chip" style={{ display: "inline-block" }} href="https://www.w3.org/Style/CSS" rel="noopener" target="_blank">CSS</a> <a className="chip" style={{ display: "inline-block" }} href="https://getbootstrap.com" rel="noopener" target="_blank">Bootstrap</a> <a className="chip" style={{ display: "inline-block" }} href="https://vuejs.org" target="_blank" rel="noopener">VueJS</a> <a className="chip" style={{ display: "inline-block" }} href="https://palletsprojects.com/p/flask" rel="noopener" target="_blank">Flask</a></span>}
                    desc="As YoungWonks's 2021 Summer Open Source Project, GeoRepair is a geotagging web application used to scan public property in need of repair."
                    button={<a role="button" data-bs-toggle="modal" href="#georepair" data-capone="Homepage" data-captwo="Signup Page" data-capthree="Forum" data-descone="Developed by me, the homepage provides basic information about our app. It showcases features and gives you a way to download our app." data-desctwo="The signup page was developed by me and another developer, and it uses WTForms to sign a new user up in the database." data-descthree="Also developed by me, the forum is still in progress and is very data heavy, making numerous API calls and giving users a clean, good-looking layout for viewing uploaded scans." data-heading="GeoRepair - An Open Source Project" data-desc="GeoRepair is a geotagging web app built with Flask and VueJS. It allows you to scan public-owned objects that are in need of repair and upload them to a database. You can view all entries near you on the forum, and view your account's scans separately on the gallery. As a Frontend developer on this project, I worked on the HTML markup and CSS styling, as well as some backend in Flask and interaction with Vue and jQuery." data-href="https://github.com/YoungWonks/ywsos2021_web" data-opentext="view on github" data-color="var(--bs-dark)">
                        <button className="btn btn-light">
                            learn more
                        </button>
                    </a>} />
                <Project header="Music Album Covers" type="design" image={albumcovers}
                    desc={`Using Canva, I designed a multidude of album covers for each song in my album Beat Box as if it were a single.`}
                    button={<a href="https://drive.google.com/drive/folders/19Uw374XJPUG6UCvEFpKNgzGgS0rzwi6G?usp=sharing" target="_blank" rel="noopener">
                        <button className="btn btn-light">
                            <i className="mdi mdi-open-in-new"></i><span style={{ width: 2, display: "inline-block" }}></span>
                            view on drive
                        </button>
                    </a>} />
                <Project header="Romeo and Juliet Spring Outdoor Show 2022 - LHS Studio 74" type="music" image={romeojuliet}
                    desc="In Lynbrook High School Studio 74's annual Spring Outdoor show, I have been cast as
                    Balthasar in the play Romeo and Juliet, performing through May 2022."
                    button={<a href="http://shakespeare.mit.edu/romeo_juliet/full.html" target="_blank" rel="noopener">
                        <button className="btn btn-light">
                            <i className="mdi mdi-open-in-new"></i><span style={{ width: 2, display: "inline-block" }}></span>read the script
                        </button>
                    </a>} />
                <Project header="Sword Selection - A Minecraft Mod" type="cs" image={swordselection} subheader={<span><a className="chip" style={{ display: "inline-block" }} href="https://java.com" rel="noopener" target="_blank">Java</a> <a className="chip" style={{ display: "inline-block" }} href="https://minecraftforge.net" rel="noopener" target="_blank">Minecraft Forge</a></span>}
                    desc="My first mod for Minecraft, I created Sword Selection using Java and Gradle through the Minecraft Forge API."
                    button={<a href="https://snehilkakani.me/SwordSelection/" target="_blank" rel="noopener">
                        <button className="btn btn-light">
                            <i className="mdi mdi-open-in-new"></i><span style={{ width: 2, display: "inline-block" }}></span>
                            view on github
                        </button>
                    </a>} />
                <Project header="YEI - Econ Concepts and Instagram Posts" type="design" image={econconcepts}
                    desc={`As part of the YEI, I designed many econ concept posts for Instagram, as well as various stories and announcements.`}
                    button={<a href="https://drive.google.com/drive/folders/1p9jnuJM7ywy8azSGWwqjG6bF8lpHrp2B?usp=sharing" target="_blank" rel="noopener">
                        <button className="btn btn-light">
                            <i className="mdi mdi-open-in-new"></i><span style={{ width: 2, display: "inline-block" }}></span>
                            view on drive
                        </button>
                    </a>} />
            </div>
        </section>
    )
}

export default Portfolio