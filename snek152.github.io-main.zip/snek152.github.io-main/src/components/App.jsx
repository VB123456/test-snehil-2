import React from "react"
import $ from "jquery"

function SocialIcons(props) {
    return (
        <a className="social-link" href={props.link} rel="noopener" target="_blank">
            <button className="social-button" name={props.name}>
                <i className={`mdi mdi-${props.name}`}></i>
            </button>
        </a>
    )
}
function FloatingIcon(props) {
    return (<div className="floating-icon" id={`floating-icon${props.num}`}>
        <img alt="Floating Icon" src={props.image} />
    </div>)
}


function IconSkill(props) {
    if (props.learning != "true") {
        return (
            <div className="icon-grid-item">
                <a tabIndex="0" role="button" data-bs-toggle="popover" data-bs-trigger="hover" title={props.title} data-bs-content={`<div class='progress'><div class='progress-bar w-${props.width}' role='progressbar' aria-valuenow='${props.width}' aria-valuemin='0' aria-valuemax='100'></div> </div>`} data-bs-html="true" data-bs-placement="bottom" data-bs-animation="true" style={{ textDecoration: "none", color: "initial", boxShadow: "none !important" }}>
                    <i className={`mdi mdi-${props.icon}`}></i>
                </a>
            </div>
        )
    } else {
        return (
            <div className="icon-grid-item">
                <a tabIndex="0" role="button" data-bs-toggle="popover" data-bs-trigger="hover" title={props.title} data-bs-content="<div class='progress learning'><div class='progress-bar w-5' role='progressbar' aria-valuenow='5' aria-valuemin='0' aria-valuemax='100'></div><div class='progress-bar w-95 learningprogress' role='progressbar' aria-valuenow='95' aria-valuemin='0' aria-valuemax='100'>Learning<div>" data-bs-html="true" data-bs-placement="bottom" data-bs-animation="true" style={{ textDecoration: "none", color: "initial", boxShadow: "none !important" }}>
                    <i className={`mdi mdi-${props.icon}`}></i>
                </a>
            </div>
        )
    }
}

function Project(props) {
    return (
        <div className={`grid-item project ${props.type}`}>
            <span data-aos="zoom-in" data-aos-once="true" data-aos-offset="-200">
                <span className="project-image"><img src={props.image} /></span>
                <span className="project-content">
                    <h6 className="project-header">{props.header}</h6>
                    <h6 className="project-subheader">
                        {props.subheader}
                    </h6>
                    <p className="project-desc">{props.desc}</p>
                    {props.button}
                </span>
            </span>
        </div>
    )
}

function ProjectModal() {
    let returnlist = []
    $('[data-bs-toggle=modal]').each(function (index, element) {
        var capcolor = "rgba(0,0,0,0.6)"
        if ($(element).data("color") === "var(--bs-dark)") capcolor = "rgba(255,255,255,0.6)"
        const bgcolor = {
            color: $(element).data("color")
        }
        const capbg = {
            backgroundColor: capcolor,
            borderRadius: "10px",
            paddingRight: "0.5rem",
            paddingLeft: "0.5rem"
        }
        returnlist.push(
            <div id={element.getAttribute("href").substring(1)} className="modal fade" aria-hidden="true" aria-labelledby="modalLabel" tabIndex="-1">
                <div className="modal-dialog modal-dialog-centered modal-dialog-scrollable modal-lg">
                    <div className="modal-content">
                        <div className="modal-header">
                            <div id={`modalCarousel${index}`} className="carousel slide" data-bs-ride="carousel">
                                <div className="carousel-indicators">
                                    <button type="button" data-bs-target={`#modalCarousel${index}`} data-bs-slide-to="0" className="active" aria-current="true" aria-label="Slide 1">
                                    </button>
                                    <button type="button" data-bs-target={`#modalCarousel${index}`} data-bs-slide-to="1"
                                        aria-label="Slide 2"></button>
                                    <button type="button" data-bs-target={`#modalCarousel${index}`} data-bs-slide-to="2"
                                        aria-label="Slide 3"></button>
                                </div>
                                <div className="carousel-inner">
                                    <div className="carousel-item active" data-bs-interval="5000">
                                        <img src={`https://raw.githubusercontent.com/SneK152/snek152.github.io/main/src/images/projects/${element.getAttribute("href").substring(1)}/img1.png`} className="d-block w-100" alt="..." />
                                        <div className="carousel-caption d-none d-md-block" style={capbg}>
                                            <h5 style={bgcolor}>{$(element).data("capone")}</h5>
                                            <p style={bgcolor}>{$(element).data("descone")}</p>
                                        </div>
                                    </div>
                                    <div className="carousel-item" data-bs-interval="5000">
                                        <img src={`https://raw.githubusercontent.com/SneK152/snek152.github.io/main/src/images/projects/${element.getAttribute("href").substring(1)}/img2.png`} className="d-block w-100" alt="..." />
                                        <div className="carousel-caption d-none d-md-block" style={capbg}>
                                            <h5 style={bgcolor}>{$(element).data("captwo")}</h5>
                                            <p style={bgcolor}>{$(element).data("desctwo")}</p>
                                        </div>
                                    </div>
                                    <div className="carousel-item" data-bs-interval="5000">
                                        <img src={`https://raw.githubusercontent.com/SneK152/snek152.github.io/main/src/images/projects/${element.getAttribute("href").substring(1)}/img3.png`} className="d-block w-100" alt="..." />
                                        <div className="carousel-caption d-none d-md-block" style={capbg}>
                                            <h5 style={bgcolor}>{$(element).data("capthree")}</h5>
                                            <p style={bgcolor}>{$(element).data("descthree")}</p>
                                        </div>
                                    </div>
                                </div>
                                <button className="carousel-control-prev" type="button" data-bs-target={`#modalCarousel${index}`} data-bs-slide="prev">
                                    <span className="carousel-control-prev-icon" aria-hidden="true"></span>
                                    <span className="visually-hidden">Previous</span>
                                </button>
                                <button className="carousel-control-next" type="button" data-bs-target={`#modalCarousel${index}`} data-bs-slide="next">
                                    <span className="carousel-control-next-icon" aria-hidden="true"></span>
                                    <span className="visually-hidden">Next</span>
                                </button>
                            </div>
                        </div>
                        <div className="modal-body">
                            <h3 className="modal-title" id={`modalLabel${index}`}>{$(element).data("heading")}</h3>
                            <p className="desc">{$(element).data("desc")}</p>
                        </div>
                        <div className="modal-footer">
                            <a target="_blank" href={$(element).data("href")} rel="noopener">
                                <button className="btn btn-primary">
                                    <i className="mdi mdi-open-in-new"></i> {$(element).data("opentext")}
                                </button>
                            </a>
                            <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                    </div>
                </div>
            </div>
        )
    })
    return returnlist
}


export { SocialIcons, FloatingIcon, IconSkill, Project, ProjectModal }
export default function Preloader() {
    return (<div id="preloading">
        <div className="spinner">
            <div className="bounce1"></div>
            <div className="bounce2"></div>
            <div className="bounce3"></div>
            <div className="bounce4"></div>
            <div className="bounce5"></div>
            <div className="bounce6"></div>
        </div>
    </div>)
}